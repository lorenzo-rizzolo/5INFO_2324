<div>
    ICON
</div>

<style>
    div {
        border: 2px solid green;
        width: 64px;
        height: 64px;
        margin: 5px;
    }
</style>