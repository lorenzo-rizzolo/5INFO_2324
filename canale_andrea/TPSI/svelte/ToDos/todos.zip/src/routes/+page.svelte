<script>
	import TodoList from "../components/todo_list.svelte";


</script>

<TodoList></TodoList>