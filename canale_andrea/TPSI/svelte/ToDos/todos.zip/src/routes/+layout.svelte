<main>
    <slot />
</main>

<style>
    main {
        border: 3px solid red;
        width: 60%;
        height: 90vh;
        margin: auto;
    }
</style>